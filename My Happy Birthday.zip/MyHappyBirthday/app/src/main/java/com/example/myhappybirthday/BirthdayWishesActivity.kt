package com.example.myhappybirthday

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.myhappybirthday.R

class BirthdayWishesActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_birthday_wishes)

        // Menemukan view berdasarkan id
        val textViewMessage: TextView = findViewById(R.id.textViewMessage)
        val textViewTo: TextView = findViewById(R.id.textViewTo)
        val textViewFrom: TextView = findViewById(R.id.textViewFrom)
        val buttonShare: Button = findViewById(R.id.buttonShare)

        // Mendapatkan data dari Intent
        val from = intent.getStringExtra("FROM") ?: "Unknown Sender"
        val quotes = intent.getStringExtra("QUOTES") ?: "Best Wishes!"
        val to = intent.getStringExtra("TO") ?: "Friend"

        // Menampilkan pesan ucapan di TextView
        textViewMessage.text = quotes
        textViewTo.text = "To: $to"
        textViewFrom.text = "From: $from"

        // Implicit Intent untuk berbagi pesan
        buttonShare.setOnClickListener {
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, "To: $to\n$quotes\nFrom: $from")
            }
            startActivity(Intent.createChooser(shareIntent, getString(R.string.share_message_chooser)))
        }
    }
}
