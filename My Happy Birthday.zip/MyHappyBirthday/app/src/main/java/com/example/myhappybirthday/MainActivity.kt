package com.example.myhappybirthday

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button
import android.widget.EditText


class MainActivity : AppCompatActivity() {

    private lateinit var editTextFrom: EditText
    private lateinit var editTextQuotes: EditText
    private lateinit var editTextTo: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        editTextFrom = findViewById(R.id.editTextFrom)
        editTextQuotes = findViewById(R.id.editTextQuotes)
        editTextTo = findViewById(R.id.editTextTo)
        val buttonSend: Button = findViewById(R.id.buttonSend)

        buttonSend.setOnClickListener {
            val from = editTextFrom.text.toString()
            val quotes = editTextQuotes.text.toString()
            val to = editTextTo.text.toString()

            // Mengirim data ke BirthdayWishesActivity menggunakan Intent
            val intent = Intent(this, BirthdayWishesActivity::class.java).apply {
                putExtra("FROM", from)
                putExtra("QUOTES", quotes)
                putExtra("TO", to)
            }
            startActivity(intent)
        }
    }
}
